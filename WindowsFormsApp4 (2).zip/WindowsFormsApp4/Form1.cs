﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        int toplam = 0;
        int a;
        public Form1()
        {
            InitializeComponent();
            // Form yüklendiğinde listView1 için SelectedIndexChanged olayını bağlayalım
            listView1.SelectedIndexChanged += listView1_SelectedIndexChanged;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listView1.View = View.Details;
            listView1.GridLines = true;
            listView1.FullRowSelect = true;

            listView1.Columns.Add("Ürün Adı", 80);
            listView1.Columns.Add("Fiyatı", 80);
            listView1.Columns.Add("Stok", 80);

            listView2.View = View.Details;
            listView2.GridLines = true;
            listView2.FullRowSelect = true;

            listView2.Columns.Add("Ürün Adı", 80);
            listView2.Columns.Add("Fiyatı", 80);
            listView2.Columns.Add("Miktar", 80);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] row = { textBox1.Text, textBox2.Text, textBox3.Text };
            var satir = new ListViewItem(row);
            listView1.Items.Add(satir);
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                ListViewItem selectedItem = listView1.SelectedItems[0];
                textBox4.Text = selectedItem.SubItems[0].Text;
                textBox5.Text = selectedItem.SubItems[1].Text;
                textBox6.Text = selectedItem.SubItems[2].Text;
                label7.Text = "Ürün Adı: " + selectedItem.SubItems[0].Text;
                label8.Text = "Fiyatı: " + selectedItem.SubItems[1].Text;
            }


        }

        private void button3_Click(object sender, EventArgs e)
        {
            ListViewItem selectedItem = listView1.SelectedItems[0];
            selectedItem.SubItems[0].Text = textBox4.Text;
            selectedItem.SubItems[1].Text = textBox5.Text;
            selectedItem.SubItems[2].Text = textBox6.Text;

            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            
        }
        int kalanstok;
        int stok;
        private void button2_Click_1(object sender, EventArgs e)
        {

            ListViewItem selectedItem = listView1.SelectedItems[0];
            a = Convert.ToInt32(selectedItem.SubItems[1].Text) * Convert.ToInt32(textBox7.Text);
            int b = Convert.ToInt32(selectedItem.SubItems[2].Text) - Convert.ToInt32(textBox7.Text);

            if (b < 0)
            {
                const string message =
        "Alacağınız üründen stoklarımızda alacağınız adetten az kalmıştır. Lütfen Miktarı stoklara göre seçiniz.";
                const string caption = "Stok Yetersiz";
                var result = MessageBox.Show(message, caption,
                                             MessageBoxButtons.OK,
                                             MessageBoxIcon.Warning);
                
            }
            
            else {
                string[] value1 = { selectedItem.SubItems[0].Text, a.ToString(), textBox7.Text };
                string[] value = value1;
                string[] row = value;
                var satir = new ListViewItem(row);
                listView2.Items.Add(satir);
                stok = Convert.ToInt32(selectedItem.SubItems[2].Text);
                kalanstok = stok - Convert.ToInt32(textBox7.Text);
                selectedItem.SubItems[2].Text = kalanstok.ToString();
                toplam += a;
                label11.Text = "Toplam: "+toplam;
            }
            
        }
        int gtoplam;
        private void button4_Click(object sender, EventArgs e)
        {
            gtoplam += toplam;
            label11.Text = "Toplam: "+toplam;
            label12.Text = "Günlük Toplam: "+gtoplam;

        }
        int silinenstok;
        private void button5_Click(object sender, EventArgs e)
        {
            ListViewItem selectedItem = listView1.SelectedItems[0];
            stok+=silinenstok;
            selectedItem.SubItems[2].Text = stok.ToString();
            ListViewItem selectedItem1 = listView2.SelectedItems[0];
            silinenstok = Convert.ToInt32(selectedItem1.SubItems[2].Text);
            //ListViewItem selectedItem = listView2.SelectedItems[0];
            int silinenIndex=Convert.ToInt32(selectedItem1.SubItems[1].Text);
            toplam -= silinenIndex;
            label11.Text = "Toplam: "+toplam;
            listView2.Items.Remove(listView2.SelectedItems[0]);
        }

        private void listView2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
//